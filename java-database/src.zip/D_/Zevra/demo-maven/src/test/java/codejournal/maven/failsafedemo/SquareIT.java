package codejournal.maven.failsafedemo;
import org.junit.jupiter.api.Test;

public class SquareIT {
    @Test
    public void integrationtest1(){
    }
    @Test
    public void integrationtest2(){

    }
}
