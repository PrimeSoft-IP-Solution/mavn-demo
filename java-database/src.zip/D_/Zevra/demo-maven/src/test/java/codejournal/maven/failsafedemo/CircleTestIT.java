package codejournal.maven.failsafedemo;

import org.junit.jupiter.api.Test;

public class CircleTestIT {
    @Test
    public void integrationtest1(){
    }
    @Test
    public void integrationtest2(){

    }
    @Test
    public void integrationtest3(){

    }
    @Test
    public void integrationtest4(){

    }
}
