package com.example.demo.person;

import org.springframework.data.repository.CrudRepository;

public interface GetPerson extends CrudRepository<Person, Integer> {

}
